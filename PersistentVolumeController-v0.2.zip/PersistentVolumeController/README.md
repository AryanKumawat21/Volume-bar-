# Persistent Volume Controller v0.2

Native Kotlin Android utility for Android 10+ / Redmi Note 7 Pro class devices.

## Current implementation
- Foreground-service persistent notification
- Main volume context: Media while music/audio is active, otherwise Ringtone
- Notification shows current level as a native progress indicator and opens the full controls on tap
- Optional +/- notification actions (OFF by default)
- Three-dot/full controls are implemented in the app UI
- Battery optimization shortcut
- Boot restart preference
- No internet, login, ads, analytics, or AI

## Important Android limitation
Android's public notification RemoteViews API does not provide a reliable arbitrary interactive SeekBar callback in a standard notification. Therefore the notification uses the native progress indicator for the main slider and opens the full interactive volume UI on tap. Optional +/- actions remain directly interactive.

## Build
Open the project in Android Studio with Android SDK 35 installed, then Build > Build APK(s).
