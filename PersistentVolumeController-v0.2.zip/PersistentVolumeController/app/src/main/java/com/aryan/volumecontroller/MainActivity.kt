package com.aryan.volumecontroller

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var serviceSwitch: Switch
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48,48,48,48) }
        val title = TextView(this).apply { text = "Persistent Volume Controller"; textSize = 24f }
        status = TextView(this).apply { textSize = 16f; setPadding(0,24,0,24) }
        serviceSwitch = Switch(this).apply { text = "Enable volume notification"; isChecked = prefs.getBoolean("enabled", false) }
        val buttons = Switch(this).apply { text = "Volume + / − buttons"; isChecked = prefs.getBoolean("buttons", false) }
        val battery = Button(this).apply { text = "Battery optimization settings" }
        root.addView(title); root.addView(status); root.addView(serviceSwitch); root.addView(buttons); root.addView(battery)
        setContentView(root)
        updateStatus()
        serviceSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("enabled", checked).apply()
            if (checked) {
                if (android.os.Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
                ContextCompat.startForegroundService(this, Intent(this, VolumeService::class.java).putExtra("buttons", buttons.isChecked))
            } else stopService(Intent(this, VolumeService::class.java))
            updateStatus()
        }
        buttons.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("buttons", checked).apply()
            if (prefs.getBoolean("enabled", false)) startServiceCompat()
        }
        battery.setOnClickListener {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } else startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }
    private fun startServiceCompat() { ContextCompat.startForegroundService(this, Intent(this, VolumeService::class.java).putExtra("buttons", prefs.getBoolean("buttons", false))) }
    private fun updateStatus() { status.text = if (prefs.getBoolean("enabled", false)) "Service: enabled" else "Service: disabled" }
}
