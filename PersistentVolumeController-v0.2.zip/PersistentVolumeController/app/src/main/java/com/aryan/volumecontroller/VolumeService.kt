package com.aryan.volumecontroller

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class VolumeService : Service() {
    private lateinit var audio: AudioManager
    private val channelId = "volume_controls"
    private val notificationId = 1001

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(notificationId, buildNotification())
        return START_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Volume controls", NotificationManager.IMPORTANCE_LOW).apply {
                    setShowBadge(false)
                    description = "Persistent volume control"
                }
            )
        }
    }

    private fun buildNotification(): Notification {
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val buttons = prefs.getBoolean("buttons", false)
        val mainStream = if (audio.isMusicActive) AudioManager.STREAM_MUSIC else AudioManager.STREAM_RING
        val max = audio.getStreamMaxVolume(mainStream).coerceAtLeast(1)
        val current = audio.getStreamVolume(mainStream).coerceIn(0, max)

        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val down = PendingIntent.getService(
            this, 2, Intent(this, VolumeActionReceiver::class.java).setAction("DOWN").putExtra("stream", mainStream),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val up = PendingIntent.getService(
            this, 3, Intent(this, VolumeActionReceiver::class.java).setAction("UP").putExtra("stream", mainStream),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle(if (mainStream == AudioManager.STREAM_MUSIC) "Media volume" else "Ringtone volume")
            .setContentText("${current * 100 / max}%  •  tap to open full controls")
            .setProgress(max, current, false)
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)

        if (buttons) {
            builder.addAction(android.R.drawable.ic_media_previous, "−", down)
            builder.addAction(android.R.drawable.ic_media_next, "+", up)
        }
        return builder.build()
    }

    fun refresh() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(notificationId, buildNotification())
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

