package com.aryan.volumecontroller

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import androidx.core.content.ContextCompat

class VolumeActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = intent.getIntExtra("stream", AudioManager.STREAM_RING)
        val current = audio.getStreamVolume(stream)
        val max = audio.getStreamMaxVolume(stream)
        val next = if (intent.action == "UP") (current + 1).coerceAtMost(max) else (current - 1).coerceAtLeast(0)
        audio.setStreamVolume(stream, next, 0)
        if (context.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("enabled", false)) {
            ContextCompat.startForegroundService(context, Intent(context, VolumeService::class.java))
        }
    }
}
