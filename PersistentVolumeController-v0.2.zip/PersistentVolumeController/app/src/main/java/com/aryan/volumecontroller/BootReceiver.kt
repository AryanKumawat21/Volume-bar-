package com.aryan.volumecontroller

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && context.getSharedPreferences("settings", Context.MODE_PRIVATE).getBoolean("enabled", false)) {
            ContextCompat.startForegroundService(context, Intent(context, VolumeService::class.java))
        }
    }
}
